/**
 * Contains classes for working with RAF (Fujifilm camera raw) format files.
 */
package com.drew.imaging.raf;
