/**
 * Helper functions for working with byte arrays during object serialization.
 */
package org.hipi.util;