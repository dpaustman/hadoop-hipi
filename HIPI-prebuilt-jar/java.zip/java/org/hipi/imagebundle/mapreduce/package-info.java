/**
 * Classes for processing HIBs including producing input splits and reading and
 * decoding image records in the context of a MapReduce program.
 */
package org.hipi.imagebundle.mapreduce;