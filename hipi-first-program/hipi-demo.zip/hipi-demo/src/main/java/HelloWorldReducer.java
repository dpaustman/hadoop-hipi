import org.hipi.image.FloatImage;
import org.hipi.image.HipiImageHeader;
import org.hipi.imagebundle.mapreduce.HibInputFormat;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.io.IOException;
public class HelloWorldReducer extends Reducer<IntWritable, FloatImage, IntWritable, Text> {

    public void reduce(IntWritable key, Iterable<FloatImage> values, Context context)
            throws IOException, InterruptedException {

        // Create FloatImage object to hold final result
        FloatImage avg = new FloatImage(1, 1, 3);

        // Initialize a counter and iterate over IntWritable/FloatImage records from mapper
        int total = 0;
        for (FloatImage val : values) {
            avg.add(val);
            total++;
        }

        if (total > 0) {
            // Normalize sum to obtain average
            avg.scale(1.0f / total);
            // Assemble final output as string
            float[] avgData = avg.getData();
            String result = String.format("Average pixel value: %f %f %f", avgData[0], avgData[1], avgData[2]);
            // Emit output of job which will be written to HDFS
            context.write(key, new Text(result));
        }

    } // reduce()

} // HelloWorldReducer