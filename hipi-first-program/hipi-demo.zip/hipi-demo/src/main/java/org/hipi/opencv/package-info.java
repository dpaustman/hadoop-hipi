/**
 * Helper classes and utility functions which facilitate interactions between HIPI and OpenCV.
 */
package org.hipi.opencv;