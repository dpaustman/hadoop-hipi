/**
 * Classes for storing and manipulating collections of images.
 */
package org.hipi.imagebundle;