/**
 * Contains classes for the extraction and modelling of ICC (International Color Consortium) profile metadata.
 */
package com.drew.metadata.icc;
