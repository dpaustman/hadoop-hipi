/**
 * Contains classes for the extraction and modelling of PCX image file metadata.
 */
package com.drew.metadata.pcx;
