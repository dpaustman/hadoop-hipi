/**
 * Contains classes for working with JPEG files.
 */
package com.drew.imaging.jpeg;
