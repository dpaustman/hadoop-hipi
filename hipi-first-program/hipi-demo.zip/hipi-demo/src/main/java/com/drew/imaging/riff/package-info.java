/**
 * Contains classes for working with RIFF format files, such as WebP.
 */
package com.drew.imaging.riff;
