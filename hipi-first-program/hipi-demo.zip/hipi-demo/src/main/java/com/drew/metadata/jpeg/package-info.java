/**
 * Contains classes for the extraction and modelling of JPEG file format metadata.
 */
package com.drew.metadata.jpeg;
