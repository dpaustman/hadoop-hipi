/**
 * Contains classes for the extraction and modelling of Exif metadata and camera manufacturer-specific makernotes.
 */
package com.drew.metadata.exif;
